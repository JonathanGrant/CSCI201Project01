import java.util.Scanner;
public class FirstClass {
	
	//First we create a scanner variable to read user input
	static Scanner keyboard = new Scanner(System.in); 
	static int rows = 0; //variables
	static int columns = 0;
	static boolean isAdmin = false;
	
	public static void main(String[] args){
		//Check if user is an Admin
		System.out.println("Are you an Admin?"); 
		String isA = keyboard.nextLine();
		if(isA.equals("A")){
			//run Administrative mode
			isAdmin = true;
			AdminMode();
		} else {
			//run normal user mode
			UserMode();
		}
	}
	
	public static void AdminMode(){
		System.out.println("Admin mode initiated");
		String[][] AdminGrid = CreateGrid();
		AdminGrid = fillGrid(AdminGrid);
		System.out.println("Here is the grid, just for you, Admin!");
		printGrid(AdminGrid);
		System.out.println("\nAdmin Result: " + getZigZag(AdminGrid));
		isAdmin = false;
		System.out.println("\nResult: " + getZigZag(AdminGrid));
	}
	
	public static void UserMode(){
		String[][] UserGrid = CreateGrid();
		UserGrid = fillGrid(UserGrid);
		System.out.println("Result: " + getZigZag(UserGrid));
	}
	
	public static String[][] CreateGrid(){
		//Loop while user doesn't understand the definition of an integer
		while(true){ //rows loop
			//Ask amount of rows
			System.out.println("How many rows would you like today?");
			//Take in input
			String StringRows = keyboard.next();
			//Check if input is a number
			if(isANumber(StringRows)){
				//Now we can parse the string without failure
				rows = Integer.parseInt(StringRows);
				//check if Input is a positive integer
				if(rows > 0)
					break;
				else if(rows == 0)
					System.out.println("You must have at least one row. Please try again.\n");
				else
					System.out.println("Hey! It is impossible to have a negative amount of rows. Please try again >=(.\n");
			}
		} while(true) { //columns loop
			//Ask amount of columns
			System.out.println("How many columns would you like today?");
			//Take in input
			String StringColumns = keyboard.next();
			//Check if input is a number
			if(isANumber(StringColumns)){
				//Now we can parse the string without failure
				columns = Integer.parseInt(StringColumns);
				//check if Input is a positive integer
				if(columns > 0)
					break;
				else if(columns == 0)
					System.out.println("You must have at least one row. Please try again.\n");
				else
					System.out.println("Hey! It is impossible to have a negative amount of columns. Please try again >=(.\n");
			}
		
		}
		//return grid
		return new String[rows][columns];
	}
	
	//this method finds out if the inputed string is a number, or not.
	public static boolean isANumber(String letsSee){
		return letsSee.matches("-?\\d+(\\.\\d+)?");
	}
	
	//this method fills in the grid with the user inputed letters
	public static String[][] fillGrid(String[][] myGrid){
		int lettersNeeded = rows * columns; //setting up, plugging in cables
		String letters = "";
		//clear the scanner
		keyboard.nextLine();
		
		//while the user cannot enter the right amount of letters
		while(true){
			//ask for the letters
			System.out.println("Enter " + lettersNeeded + " letters, each seperated by a single space.");
			letters = keyboard.nextLine(); 
			//check if there are enough characters
			if(letters.length() == lettersNeeded *2 - 1 || letters.length() == lettersNeeded * 2){
				//now, while adding the letters to the grid, check if each character is separated by a space
				int letterCount = 0;
				boolean breaker = false;
				for(int i = 0; i < rows; i++){ //fill the grid using nested for loops
					for(int j = 0; j < columns; j++){
						myGrid[i][j] = ""+letters.charAt(letterCount);
						letterCount++;
						if(letterCount < letters.length() && letters.charAt(letterCount) != ' ') {
							//someone didn't follow directions EXACTLY as asked...
							breaker = true;
							System.out.println("You had two characters following each other with no spaces between them... ");
							break;
						}
						//otherwise, increment the letter count
						letterCount++;
					}
					if(breaker) break;
				}
				if(!breaker) //if the for loop executed without problems, then you can break
					break;
			}
			else if (letters.length() < lettersNeeded * 2)
				System.out.println("Too few letters, try again!");
			else
				System.out.println("Too many letters man, try again!");
		}
		return myGrid;
	}
	
	//this method returns the zig zag string
	public static String getZigZag(String[][] myGrid){
		int rowA = 0, columnA = 0;
		String ziggyzag = "";
		boolean flag = false;
		
		//run until completion
		while(true){
			//run while going down, until have to go up
			while(true){
				if(isAdmin)
					ziggyzag = ziggyzag + "\nR:" + rowA + "    C:" + columnA + "    L:";
				ziggyzag = ziggyzag + myGrid[rowA][columnA];
				if(columnA + 1 == columns){
					flag = true; //set off the alarm
					break; //end the loop
				}
				//otherwise, increment
				rowA++;
				columnA++;
				if(rowA + 1 == rows) break; //switch directions
			}
			if(flag) break; //if zig zag is over, break
			//run while going up, until have to go down
			while(true){
				if(isAdmin)
					ziggyzag = ziggyzag + "\nR:" + rowA + "    C:" + columnA + "    L:";
				ziggyzag = ziggyzag + myGrid[rowA][columnA];
				if(columnA + 1 == columns){
					flag = true; //set off the alarm
					break; //end the loop
				}
				//otherwise, increment
				rowA--;
				columnA++;
				if(rowA == 0) break; //switch directions
			}
			if(flag) break; //if zig zag is over, break
		}
		return ziggyzag;
	}
	
	public static void printGrid(String[][] myGrid){
		//use for loops
		for(int i = 0; i < rows; i ++){
			for(int j = 0; j < columns; j++){
				System.out.print(myGrid[i][j] + " ");
			}
			System.out.println(); //next row
		}
	}
}
